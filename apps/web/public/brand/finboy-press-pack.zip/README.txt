FinBoy press resources

FinBoy is an expense diary for India. People can add spending through WhatsApp or the web and review records, budgets and reports. Text entries and typed questions are free, subject to usage limits. Voice, photo capture and supported Google Pay statement imports are Premium. New households start with 30 days of Premium. Voice supports English, Hindi and Malayalam. Gmail import is invite-only.

The four screenshots and the 32-second captioned video show FinBoy's interactive on-site WhatsApp simulation. All names, amounts and entries are made up. They are not screenshots of an actual user's account or a live conversation. The simulation uses FinBoy's scripted replies; voice notes in the real product require Premium.

FinBoy does not automatically see every bank or UPI transaction. It processes the information a user supplies and saves structured records; the privacy policy explains handling and deletion. The example does not demonstrate an automatic bank connection or a native mobile app.

Website: https://finboy.io/
Interactive sample: https://finboy.io/features/whatsapp-expense-tracker
Current pricing: https://finboy.io/pricing
Privacy policy: https://finboy.io/privacy-policy
Press contact: support@finboy.io

Prepared 15 November 2026. Product details may change; check the public pages above for current information.
